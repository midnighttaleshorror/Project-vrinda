package com.sandip.jarvis

import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONObject
import kotlin.coroutines.resume

class VrindaService : Service() {
    companion object {
        @Volatile var instance: VrindaService? = null
        const val CHANNEL = "vrinda_bg"
        const val ACTION_STOP = "com.sandip.jarvis.STOP"
        val running: Boolean get() = instance != null
        fun start(ctx: Context) { ContextCompat.startForegroundService(ctx, Intent(ctx, VrindaService::class.java)) }
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, VrindaService::class.java)) }

        private val WAKE = Regex(
            "vrinda|brinda|vrindha|verinda|vrinta|brinta|prinda|printa|প্রিন্টা|প্রিন্দা|ব্রিন্টা|বৃন্টা|प्रिंदा|प्रिंटा|ब्रिंटा|वृंटा|वृंदा|वृन्दा|व्रिन्दा|ब्रिंदा|বৃন্দা|ব্রিন্দা",
            RegexOption.IGNORE_CASE
        )
        private val YES = Regex("\\b(yes|yeah|yep|haan|han|ha|ok|okay|sure)\\b|हाँ|हां|जी|ठीक|হ্যাঁ|হ্যা|হাঁ", RegexOption.IGNORE_CASE)
        private val NO = Regex("\\b(no|nope|nahi|nahin|na)\\b|नहीं|नही|না|নাহ", RegexOption.IGNORE_CASE)
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null
    private var started = false
    private var paused = false
    private var lastError = 0

    private lateinit var store: SecureStore
    private lateinit var speaker: Speaker
    private lateinit var brain: Brain
    private lateinit var actions: Actions
    private lateinit var recognizer: SpeechRecognizer

    override fun onCreate() {
        super.onCreate()
        instance = this
        store = SecureStore(this)
        speaker = Speaker(this, store)
        brain = Brain()
        actions = Actions(
            this,
            confirm = { q ->
                speaker.speakSuspend("I need your confirmation on the screen.", LANGS[store.langIdx].locale)
                Confirmer.ask(this, q, store.strictConfirm)
            },
            permission = { p -> ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED },
            requireSession = true
        )
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            startForeground(1, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!started) { started = true; loop() }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        instance = null
        job?.cancel()
        scope.cancel()
        recognizer.destroy()
        speaker.shutdown()
        super.onDestroy()
    }

    /** The app screen is open and uses the microphone itself, so background listening pauses. */
    fun pause() { paused = true; job?.cancel(); recognizer.cancel() }
    fun resume() { paused = false; if (started) loop() }

    private fun notification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Vrinda background", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 1, Intent(this, VrindaService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Vrinda is listening")
            .setContentText("Say “Hey Vrinda”")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop", stop
                ).build()
            )
            .build()
    }

    private fun loop() {
        job?.cancel()
        job = scope.launch {
            while (isActive) {
                if (paused) { delay(500); continue }
                val heard = listenOnce()
                if (lastError == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { stopSelf(); return@launch }
                if (heard == null) { delay(600); continue }
                val m = WAKE.find(heard) ?: continue
                val cmd = heard.substring(m.range.last + 1).trim(' ', ',', '.', '!', '?', '-')
                handle(cmd)
            }
        }
    }

    private suspend fun listenOnce(): String? = suspendCancellableCoroutine { cont ->
        lastError = 0
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, LANGS[store.langIdx].tag)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
            override fun onError(e: Int) { lastError = e; if (cont.isActive) cont.resume(null) }
            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (cont.isActive) cont.resume(t)
            }
        })
        cont.invokeOnCancellation { recognizer.cancel() }
        recognizer.startListening(i)
    }

    private suspend fun handle(first: String) {
        var cmd = first
        val lang = LANGS[store.langIdx]
        if (cmd.isBlank()) {
            speaker.speakSuspend(
                when (store.langIdx) { 1 -> "जी?"; 2 -> "বলুন?"; else -> "Yes?" }, lang.locale
            )
            cmd = listenOnce() ?: return
        }
        val reply = runCatching {
            brain.chat(store.apiKey, store.model, cmd, onSay = { speaker.speakSuspend(it, detectLocale(it)) }) { n, a -> guarded(n, a) }
        }.getOrElse { "Sorry, something went wrong." }
        speaker.speakSuspend(reply, detectLocale(reply))
    }

    private suspend fun guarded(name: String, args: JSONObject): String {
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (km.isDeviceLocked && name in setOf("make_call", "send_sms", "whatsapp_message", "read_screen", "click_text", "type_text", "scroll", "press_key", "delete_text",
                "read_notifications", "reply_notification", "calendar_events"))
            return "The phone is locked, so I cannot do that. The owner must unlock the phone first."
        return actions.run(name, args)
    }

    private suspend fun voiceConfirm(q: String): Boolean {
        speaker.speakSuspend("$q Say yes or no.", detectLocale(q).let { if (it.language == "en") LANGS[store.langIdx].locale else it })
        val ans = listenOnce() ?: return false
        return YES.containsMatchIn(ans) && !NO.containsMatchIn(ans)
    }
}
