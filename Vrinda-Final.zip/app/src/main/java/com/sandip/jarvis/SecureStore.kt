package com.sandip.jarvis

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class SecureStore(ctx: Context) {
    private val sp = EncryptedSharedPreferences.create(
        ctx, "jarvis_secure",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
    var apiKey: String
        get() = sp.getString("api_key", "") ?: ""
        set(v) { sp.edit().putString("api_key", v.trim()).apply() }
    var model: String
        get() = sp.getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
        set(v) { sp.edit().putString("model", v.trim()).apply() }

    var langIdx: Int
        get() = sp.getInt("lang_idx", 0)
        set(v) { sp.edit().putInt("lang_idx", v).apply() }

    var strictConfirm: Boolean
        get() = sp.getBoolean("strict_confirm", true)
        set(v) { sp.edit().putBoolean("strict_confirm", v).apply() }

    fun voiceFor(lang: String): String = sp.getString("voice_$lang", "") ?: ""
    fun setVoice(lang: String, name: String) { sp.edit().putString("voice_$lang", name).apply() }
}
