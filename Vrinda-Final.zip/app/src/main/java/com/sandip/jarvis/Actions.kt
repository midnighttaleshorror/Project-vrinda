package com.sandip.jarvis

import android.Manifest
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.app.SearchManager
import android.media.AudioManager
import android.os.BatteryManager
import android.os.Build
import android.os.SystemClock
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import android.provider.ContactsContract
import android.telephony.SmsManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject

class Actions(
    private val ctx: Context,
    private val confirm: suspend (String) -> Boolean,
    private val permission: suspend (String) -> Boolean,
    private val requireSession: Boolean = false
) {
    suspend fun run(name: String, a: JSONObject): String {
        if (name in SCREEN_TOOLS) gateScreen()?.let { return it }
        return dispatch(name, a)
    }

    /** Background voice commands: reading or controlling the screen needs the owner's OK, valid for 2 minutes. */
    private suspend fun gateScreen(): String? {
        if (!requireSession || SystemClock.elapsedRealtime() < Session.until) return null
        if (!confirm("Let Vrinda read and control your screen for 2 minutes?"))
            return "The owner did not approve, so I cannot read or control the screen."
        Session.until = SystemClock.elapsedRealtime() + 120_000
        return null
    }

    private suspend fun dispatch(name: String, a: JSONObject): String = when (name) {
        "make_call" -> call(a.optString("contact"))
        "send_sms" -> sms(a.optString("contact"), a.optString("message"))
        "open_app" -> openApp(a.optString("app_name"))
        "set_alarm" -> alarm(a.optInt("hour"), a.optInt("minute"), a.optString("label", "Vrinda"))
        "set_timer" -> timer(a.optInt("seconds"), a.optString("label", "Vrinda"))
        "flashlight" -> torch(a.optBoolean("on", true))
        "search_web" -> search(a.optString("query"))
        "set_volume" -> volume(a.optInt("percent"))
        "set_brightness" -> brightness(a.optInt("percent"))
        "wifi_settings" -> wifi()
        "bluetooth_settings" -> bluetooth()
        "media_control" -> media(a.optString("action"))
        "play_music" -> music(a.optString("query"))
        "battery_status" -> battery()
        "read_screen" -> VrindaAccessibility.instance?.snapshot(1500) ?: NOT_ENABLED
        "click_text" -> clickGuarded(a.optString("text"))
        "type_text" -> act { it.typeText(a.optString("text")) }
        "scroll" -> act { it.scroll(a.optString("direction", "down")) }
        "press_key" -> act { it.press(a.optString("key")) }
        "delete_text" -> deleteText(a.optString("mode", "chars"), a.optInt("count", 1))
        "read_notifications" -> VrindaNotifications.instance?.summary(a.optInt("count", 5)) ?: NO_NOTIF
        "reply_notification" -> replyNotification(a.optString("who"), a.optString("message"))
        "calendar_events" -> calendar(a.optInt("days", 1))
        "whatsapp_message" -> whatsapp(a.optString("contact"), a.optString("message"))
        else -> "Unknown action."
    }

    private fun go(i: Intent) = ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    private suspend fun resolve(who: String): Pair<String, String>? {
        if (Regex("^[+0-9 ()-]{6,}$").matches(who.trim()))
            return who.trim() to who.filter { it.isDigit() || it == '+' }
        if (!permission(Manifest.permission.READ_CONTACTS)) return null
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$who%"), null
        )?.use { c -> if (c.moveToFirst()) return c.getString(0) to c.getString(1) }
        return null
    }

    private suspend fun call(who: String): String {
        val (name, num) = resolve(who) ?: return "Contact not found, or contacts permission denied."
        if (!confirm("Call $name ($num)?")) return "The owner cancelled the call."
        if (!permission(Manifest.permission.CALL_PHONE)) return "Call permission denied."
        go(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(num))))
        return "Calling $name."
    }

    @Suppress("DEPRECATION")
    private suspend fun sms(who: String, msg: String): String {
        val (name, num) = resolve(who) ?: return "Contact not found, or contacts permission denied."
        if (!confirm("Send SMS to $name ($num):\n\"$msg\"")) return "The owner cancelled the SMS."
        if (!permission(Manifest.permission.SEND_SMS)) return "SMS permission denied."
        val sm = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
        sm.sendMultipartTextMessage(num, null, sm.divideMessage(msg), null, null)
        return "SMS sent to $name."
    }

    private fun openApp(q: String): String {
        val pm = ctx.packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = list.firstOrNull { it.loadLabel(pm).toString().equals(q, true) }
            ?: list.firstOrNull { it.loadLabel(pm).toString().contains(q, true) }
            ?: return "App not found."
        val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return "Can't open that app."
        go(i)
        return "Opened ${hit.loadLabel(pm)}."
    }

    private fun alarm(h: Int, m: Int, label: String): String {
        go(Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        return "Alarm set for %02d:%02d.".format(h, m)
    }

    private fun timer(sec: Int, label: String): String {
        go(Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, sec).putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        return "Timer started for $sec seconds."
    }

    private fun torch(on: Boolean): String {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "No flashlight found."
        cm.setTorchMode(id, on)
        return if (on) "Flashlight on." else "Flashlight off."
    }

    private fun search(q: String): String {
        go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
        return "Opened search for $q."
    }

    private fun volume(pct: Int): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, (pct.coerceIn(0, 100) * max / 100), 0)
        return "Volume set to ${pct.coerceIn(0, 100)} percent."
    }

    private fun brightness(pct: Int): String {
        if (!Settings.System.canWrite(ctx)) {
            go(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}")))
            return "I need the 'Modify system settings' permission first. I opened its page for the owner."
        }
        val cr = ctx.contentResolver
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, pct.coerceIn(0, 100) * 255 / 100)
        return "Brightness set to ${pct.coerceIn(0, 100)} percent."
    }

    private fun wifi(): String {
        go(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
        return "Opened the Wi-Fi panel. Android does not let apps switch Wi-Fi themselves, so the owner must tap the switch."
    }

    private fun bluetooth(): String {
        go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        return "Opened Bluetooth settings. Android does not let apps switch Bluetooth themselves, so the owner must tap the switch."
    }

    private fun media(action: String): String {
        val code = when (action) {
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "stop" -> KeyEvent.KEYCODE_MEDIA_STOP
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return "Done: $action."
    }

    private fun music(q: String): String {
        return try {
            go(Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                .putExtra(SearchManager.QUERY, q)
                .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*"))
            "Playing $q."
        } catch (e: Exception) {
            go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))))
            "No music app handled it, so I opened YouTube search for $q."
        }
    }

    private fun battery(): String {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return "Battery is at ${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)} percent."
    }

    /** Backspaces visibly, a few letters at a time, like a person pressing the delete key. */
    private suspend fun deleteText(mode: String, count: Int): String {
        val s = VrindaAccessibility.instance ?: return NOT_ENABLED
        s.fieldProblem()?.let { return it }
        val (text, cur) = s.fieldSnapshot() ?: return "The text field is already empty."
        val to = if (mode == "all") text.length else cur
        val from = when (mode) {
            "all" -> 0
            "word" -> {
                var i = cur
                while (i > 0 && text[i - 1].isWhitespace()) i--
                while (i > 0 && !text[i - 1].isWhitespace()) i--
                i
            }
            else -> (cur - count.coerceAtLeast(1)).coerceAtLeast(0)
        }
        val n = to - from
        if (n <= 0) return "There is nothing before the cursor to delete."
        val chunk = (n + 59) / 60
        var done = 0
        while (done < n) {
            done = minOf(n, done + chunk)
            if (!s.setField(text.substring(0, to - done) + text.substring(to), to - done))
                return "Could not delete the text."
            delay(35)
        }
        val after = text.substring(0, from) + text.substring(to)
        return "Deleted “${text.substring(from, to).takeLast(80)}”. The field now says: “${after.take(200)}”."
    }

    private val NO_NOTIF = "Notification access is off. The owner must enable it in Settings > Notification access."

    private suspend fun replyNotification(who: String, msg: String): String {
        val n = VrindaNotifications.instance ?: return NO_NOTIF
        val target = n.replyTarget(who) ?: return "I found no notification from “$who” that can be replied to."
        if (!confirm("Reply to $target: “$msg”?")) return "The owner cancelled the reply."
        return n.reply(who, msg)
    }

    private suspend fun calendar(days: Int): String {
        if (!permission(Manifest.permission.READ_CALENDAR))
            return "Calendar permission is missing. The owner must open Vrinda once and allow it."
        val begin = System.currentTimeMillis()
        val end = begin + days.coerceIn(1, 14) * 86_400_000L
        val timeFmt = java.text.SimpleDateFormat("EEE d MMM, HH:mm", java.util.Locale.getDefault())
        val dayFmt = java.text.SimpleDateFormat("EEE d MMM", java.util.Locale.getDefault())
        val out = ArrayList<String>()
        CalendarContract.Instances.query(
            ctx.contentResolver,
            arrayOf(
                CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN,
                CalendarContract.Instances.ALL_DAY, CalendarContract.Instances.EVENT_LOCATION
            ),
            begin, end
        )?.use { c ->
            while (c.moveToNext() && out.size < 15) {
                val at = java.util.Date(c.getLong(1))
                val whenText = if (c.getInt(2) == 1) dayFmt.format(at) + " (all day)" else timeFmt.format(at)
                val place = c.getString(3)?.takeIf { it.isNotBlank() }?.let { " at $it" } ?: ""
                out.add("$whenText: ${c.getString(0) ?: "(no title)"}$place")
            }
        }
        return if (out.isEmpty()) "There are no events in the next $days day(s)." else out.joinToString("\n")
    }

    private val RISKY = Regex(
        "\\b(pay|send|transfer|delete|remove|uninstall|buy|purchase|order|checkout|confirm|submit)\\b|भेजें|भुगतान|हटाएं|खरीदें|পাঠান|ডিলিট|কিনুন|পেমেন্ট",
        RegexOption.IGNORE_CASE
    )

    /** Sensitive taps (Send, Pay, Delete...) need the owner's yes first; no answer in 60s means no. */
    private suspend fun clickGuarded(q: String): String {
        if (RISKY.containsMatchIn(q)) {
            val ok = withTimeoutOrNull(60_000) { confirm("Tap “$q” on the screen?") } ?: false
            if (!ok) return "The owner did not confirm, so I did not press “$q”."
        }
        return act { it.clickText(q) }
    }

    private val NOT_ENABLED = "Screen control is off. Ask the owner to enable Vrinda in Accessibility settings."

    private suspend fun act(f: (VrindaAccessibility) -> String): String {
        val s = VrindaAccessibility.instance ?: return NOT_ENABLED
        val r = f(s)
        delay(700)
        return r + " Screen now: " + s.snapshot(500)
    }

    private suspend fun whatsapp(who: String, msg: String): String {
        val (name, num) = resolve(who) ?: return "Contact not found, or contacts permission denied."
        if (!confirm("WhatsApp to $name ($num):\n\"$msg\"")) return "The owner cancelled the message."
        var d = num.filter { it.isDigit() }
        if (d.length == 11 && d.startsWith("0")) d = d.drop(1)
        if (d.length == 10) d = "91$d"
        val uri = Uri.parse("https://wa.me/$d?text=" + Uri.encode(msg))
        var opened = false
        for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b", null)) {
            try {
                go(Intent(Intent.ACTION_VIEW, uri).apply { if (pkg != null) setPackage(pkg) })
                opened = true; break
            } catch (e: Exception) { }
        }
        if (!opened) return "Could not open WhatsApp."
        val s = VrindaAccessibility.instance
            ?: return "WhatsApp is open with the message ready. Screen control is off, so the owner must tap Send."
        delay(3500)
        val r = s.clickText("Send")
        return if (r.startsWith("Tapped")) "WhatsApp message sent to $name." else "Opened the chat but could not press Send: $r"
    }
}

object Session { @Volatile var until = 0L }

private val SCREEN_TOOLS = setOf(
    "read_screen", "click_text", "type_text", "scroll", "press_key", "delete_text",
    "read_notifications", "reply_notification", "calendar_events"
)
