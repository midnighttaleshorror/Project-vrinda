package com.sandip.jarvis

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Msg(val text: String, val user: Boolean)

class Brain {
    private var contents = JSONArray()

    private fun arr(vararg o: JSONObject) = JSONArray().also { a -> o.forEach { a.put(it) } }
    private fun strs(l: List<String>) = JSONArray().also { a -> l.forEach { a.put(it) } }
    private fun p(type: String, d: String) = JSONObject().put("type", type).put("description", d)
    private fun fn(name: String, desc: String, props: JSONObject, req: List<String>): JSONObject {
        val o = JSONObject().put("name", name).put("description", desc)
        // Gemini rejects OBJECT parameters with no properties, so tools without arguments omit "parameters".
        if (props.length() > 0)
            o.put("parameters", JSONObject().put("type", "OBJECT").put("properties", props).put("required", strs(req)))
        return o
    }

    private val tools = arr(
        JSONObject().put(
            "function_declarations", arr(
                fn("make_call", "Call a contact by name or a phone number",
                    JSONObject().put("contact", p("STRING", "Contact name or phone number")), listOf("contact")),
                fn("send_sms", "Send an SMS text message",
                    JSONObject().put("contact", p("STRING", "Contact name or phone number"))
                        .put("message", p("STRING", "Message text")), listOf("contact", "message")),
                fn("open_app", "Open an installed app by name",
                    JSONObject().put("app_name", p("STRING", "App name, e.g. WhatsApp, YouTube")), listOf("app_name")),
                fn("set_alarm", "Set an alarm at a time of day (24-hour clock)",
                    JSONObject().put("hour", p("INTEGER", "0-23")).put("minute", p("INTEGER", "0-59"))
                        .put("label", p("STRING", "Alarm label")), listOf("hour", "minute")),
                fn("set_timer", "Start a countdown timer",
                    JSONObject().put("seconds", p("INTEGER", "Duration in seconds"))
                        .put("label", p("STRING", "Timer label")), listOf("seconds")),
                fn("flashlight", "Turn the flashlight on or off",
                    JSONObject().put("on", p("BOOLEAN", "true to turn on")), listOf("on")),
                fn("search_web", "Open a Google search in the browser",
                    JSONObject().put("query", p("STRING", "Search query")), listOf("query")),
                fn("set_volume", "Set the media volume",
                    JSONObject().put("percent", p("INTEGER", "0-100")), listOf("percent")),
                fn("set_brightness", "Set the screen brightness",
                    JSONObject().put("percent", p("INTEGER", "0-100")), listOf("percent")),
                fn("wifi_settings", "Open the Wi-Fi panel (Android does not let apps toggle Wi-Fi directly)",
                    JSONObject(), listOf()),
                fn("bluetooth_settings", "Open Bluetooth settings (apps cannot toggle Bluetooth directly)",
                    JSONObject(), listOf()),
                fn("media_control", "Control music playback in whatever media app is active",
                    JSONObject().put("action", p("STRING", "one of: play_pause, next, previous, stop")), listOf("action")),
                fn("play_music", "Search for and play a song, artist or playlist in the music app",
                    JSONObject().put("query", p("STRING", "Song or artist")), listOf("query")),
                fn("battery_status", "Get the battery percentage", JSONObject(), listOf()),
                fn("read_screen", "Read the visible text of the app currently on screen", JSONObject(), listOf()),
                fn("click_text", "Tap a button, tab or item on screen by its visible text or label",
                    JSONObject().put("text", p("STRING", "Visible text or label to tap")), listOf("text")),
                fn("type_text", "Type text into the text field on screen",
                    JSONObject().put("text", p("STRING", "Text to type")), listOf("text")),
                fn("scroll", "Scroll the current screen",
                    JSONObject().put("direction", p("STRING", "up or down")), listOf("direction")),
                fn("press_key", "Press a system key",
                    JSONObject().put("key", p("STRING", "one of: back, home, recents, notifications, quick_settings, lock_screen, screenshot, power")), listOf("key")),
                fn("read_notifications", "Read the owner's latest notifications (OTP codes are hidden)",
                    JSONObject().put("count", p("INTEGER", "How many, default 5")), listOf()),
                fn("reply_notification", "Quick-reply to a message notification from a person or app (the owner confirms first)",
                    JSONObject().put("who", p("STRING", "Sender name or app name"))
                        .put("message", p("STRING", "Reply text")), listOf("who", "message")),
                fn("calendar_events", "List upcoming calendar events",
                    JSONObject().put("days", p("INTEGER", "How many days ahead, default 1")), listOf()),
                fn("delete_text", "Backspace in the text box: delete the last few characters, the last word, or everything typed",
                    JSONObject().put("mode", p("STRING", "chars, word or all"))
                        .put("count", p("INTEGER", "How many characters when mode is chars")), listOf("mode")),
                fn("whatsapp_message", "Send a WhatsApp message to a contact",
                    JSONObject().put("contact", p("STRING", "Contact name or phone number"))
                        .put("message", p("STRING", "Message text")), listOf("contact", "message"))
            )
        )
    )

    private fun system(): String =
        "You are Vrinda, a female AI assistant living on your owner Sandip's Android phone. " +
        "You are loyal to him, protective of his phone and privacy, warm, calm and efficient. " +
        "Reply in the language he speaks to you: Indian English, Hindi or Bengali (use the native script). " +
        "In Hindi, speak of yourself in the feminine. " +
        "Use the provided tools to actually perform phone actions instead of just describing them. " +
        "To operate any app step by step: read_screen to see it, click_text to tap, type_text to type, scroll, press_key for back/home/quick_settings. " +
        "Check the screen after each step and stop when the job is done. To switch Wi-Fi or Bluetooth, open quick_settings and tap the tile. " +
        "Think like a thoughtful human assistant. First work out what he really wants. If it is ambiguous (which contact, which app, what to write), ask one short question instead of guessing. " +
        "Before a multi-step task say one short sentence about what you are about to do, then do the next step, look at the screen to check it worked, and fix mistakes: if wrong text was typed, remove it with delete_text and type the right text. " +
        "If something fails, try another way before giving up, and tell him briefly what you did or found. " +
        "When he asks you to cut, remove or undo typed text, use delete_text: mode chars with a count for the last few letters, word for the last word, all for everything. " +
        "Use read_notifications for questions about new messages and calendar_events for the schedule. Never read out OTPs, passwords or verification codes. " +
        "Never operate banking, payment or password apps, and never read out passwords or one-time codes unless the owner explicitly asks. " +
        "For calls and SMS the app asks him to confirm, so just call the tool. " +
        "Keep replies to one or two short spoken sentences: no markdown, no lists unless asked. " +
        "Never reveal private data to anyone else. Refuse harmful or illegal requests politely. " +
        "Current local time: " + SimpleDateFormat("EEEE, d MMM yyyy, HH:mm", Locale.US).format(Date()) + "."

    suspend fun chat(
        key: String, model: String, text: String,
        onSay: suspend (String) -> Unit = {},
        run: suspend (String, JSONObject) -> String
    ): String {
        if (key.isBlank()) return "Please add your Gemini API key in Settings."
        if (contents.length() > 40) contents = JSONArray()
        contents.put(JSONObject().put("role", "user").put("parts", arr(JSONObject().put("text", text))))
        try {
            repeat(12) {
                val resp = withContext(Dispatchers.IO) { call(key, model) }
                val cands = resp.optJSONArray("candidates")
                if (cands == null || cands.length() == 0) return "I couldn't answer that."
                val content = cands.getJSONObject(0).optJSONObject("content") ?: return "I couldn't answer that."
                if (!content.has("role")) content.put("role", "model")
                val parts = content.optJSONArray("parts") ?: return "I couldn't answer that."
                contents.put(content)
                val list = (0 until parts.length()).map { parts.getJSONObject(it) }
                val calls = list.filter { it.has("functionCall") }
                if (calls.isEmpty()) {
                    val out = list.filter { it.has("text") && !it.optBoolean("thought", false) }
                        .joinToString(" ") { it.getString("text") }.trim()
                    return out.ifBlank { "Done." }
                }
                val said = list.filter { it.has("text") && !it.optBoolean("thought", false) }
                    .joinToString(" ") { it.getString("text") }.trim()
                if (said.isNotBlank()) onSay(said)
                val results = JSONArray()
                for (c in calls) {
                    val fc = c.getJSONObject("functionCall")
                    val name = fc.getString("name")
                    val args = fc.optJSONObject("args") ?: JSONObject()
                    val result = runCatching { run(name, args) }.getOrElse { "Failed: ${it.message}" }
                    results.put(
                        JSONObject().put(
                            "functionResponse",
                            JSONObject().put("name", name).put("response", JSONObject().put("result", result))
                        )
                    )
                }
                contents.put(JSONObject().put("role", "user").put("parts", results))
            }
        } catch (e: Exception) {
            contents = JSONArray()
            throw e
        }
        return "Sorry, I got stuck on that."
    }

    private fun call(key: String, model: String): JSONObject {
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", arr(JSONObject().put("text", system()))))
            .put("contents", contents)
            .put("tools", tools)
        val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("x-goog-api-key", key)
        conn.connectTimeout = 20000
        conn.readTimeout = 60000
        conn.doOutput = true
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val txt = stream?.bufferedReader()?.use { it.readText() } ?: ""
        // Model retired or misspelled: fall back to Google's always-current alias.
        if (code == 404 && model != "gemini-flash-latest") return call(key, "gemini-flash-latest")
        if (code !in 200..299) {
            val why = try { JSONObject(txt).getJSONObject("error").getString("message") } catch (e: Exception) { "" }
            throw IllegalStateException("Gemini error $code: ${why.take(160)}")
        }
        return JSONObject(txt)
    }
}
