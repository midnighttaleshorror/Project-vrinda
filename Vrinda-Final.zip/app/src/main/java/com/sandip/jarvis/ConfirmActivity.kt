package com.sandip.jarvis

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull

/**
 * A see-through screen that pops up over ANY app to ask the owner for a fingerprint (or Yes/No),
 * then closes and reveals the app underneath again.
 */
class ConfirmActivity : FragmentActivity() {
    companion object {
        @Volatile var pending: CompletableDeferred<Boolean>? = null
        @Volatile var current: ConfirmActivity? = null
    }

    private var finished = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        current = this
        val text = intent.getStringExtra("text") ?: "Confirm?"
        val strong = intent.getBooleanExtra("strong", true)
        val auth = BiometricManager.Authenticators.BIOMETRIC_STRONG or
            BiometricManager.Authenticators.DEVICE_CREDENTIAL
        if (strong && BiometricManager.from(this).canAuthenticate(auth) == BiometricManager.BIOMETRIC_SUCCESS) {
            val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this),
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { done(true) }
                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { done(false) }
                })
            prompt.authenticate(
                BiometricPrompt.PromptInfo.Builder()
                    .setTitle("Vrinda needs your OK")
                    .setDescription(text)
                    .setAllowedAuthenticators(auth)
                    .build()
            )
        } else {
            setContent {
                MaterialTheme(colorScheme = darkColorScheme()) {
                    AlertDialog(
                        onDismissRequest = { done(false) },
                        title = { Text("Vrinda") },
                        text = { Text(text) },
                        confirmButton = { TextButton(onClick = { done(true) }) { Text("Yes") } },
                        dismissButton = { TextButton(onClick = { done(false) }) { Text("No") } }
                    )
                }
            }
        }
    }

    private fun done(ok: Boolean) {
        if (finished) return
        finished = true
        pending?.complete(ok)
        finish()
    }

    override fun onDestroy() {
        if (current === this) current = null
        if (!finished) pending?.complete(false)
        super.onDestroy()
    }
}

object Confirmer {
    /** Shows the confirmation over whatever app is in front. No answer within 90 seconds counts as No. */
    suspend fun ask(ctx: Context, text: String, strong: Boolean): Boolean {
        ConfirmActivity.current?.finish()
        val d = CompletableDeferred<Boolean>()
        ConfirmActivity.pending = d
        ctx.startActivity(
            Intent(ctx, ConfirmActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                .putExtra("text", text)
                .putExtra("strong", strong)
        )
        val r = withTimeoutOrNull(90_000) { d.await() }
        if (r == null) { ConfirmActivity.current?.finish(); ConfirmActivity.pending = null }
        return r ?: false
    }
}
