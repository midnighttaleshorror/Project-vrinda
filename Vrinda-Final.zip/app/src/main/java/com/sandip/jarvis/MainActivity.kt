package com.sandip.jarvis

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.webkit.WebView
import android.webkit.WebViewClient
import android.speech.SpeechRecognizer
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateDpAsState
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

class Lang(val label: String, val tag: String, val locale: Locale)

val LANGS = listOf(
    Lang("English", "en-IN", Locale("en", "IN")),
    Lang("हिन्दी", "hi-IN", Locale("hi", "IN")),
    Lang("বাংলা", "bn-IN", Locale("bn", "IN"))
)

fun detectLocale(t: String): Locale = when {
    t.any { it in '\u0980'..'\u09FF' } -> Locale("bn", "IN")
    t.any { it in '\u0900'..'\u097F' } -> Locale("hi", "IN")
    else -> Locale("en", "IN")
}

const val LOCK_AFTER_MS = 30_000L

class Pending(val text: String, val result: CompletableDeferred<Boolean>)

fun granted(ctx: Context, perm: String) =
    ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED

/** One step at a time: overlay permission lets Vrinda open apps from the background; battery keeps her alive. */
fun setupBackground(ctx: Context) {
    val msg: String
    if (!Settings.canDrawOverlays(ctx)) {
        ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
        msg = "Turn on 'Display over other apps' for Vrinda, then tap this button again."
    } else if (!(ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName)) {
        ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}")))
        msg = "Allow unrestricted battery use so Android doesn't stop Vrinda."
    } else msg = "All background permissions are set ✔"
    Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
}

fun openAccessibility(ctx: Context) {
    Toast.makeText(ctx, "Find Vrinda and turn it on. If it is greyed out: App info → ⋮ → Allow restricted settings.", Toast.LENGTH_LONG).show()
    ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

class MainActivity : FragmentActivity() {
    private var unlocked by mutableStateOf(false)
    private var stoppedAt = 0L
    private lateinit var store: SecureStore
    private lateinit var speaker: Speaker

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = SecureStore(this)
        speaker = Speaker(this, store)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF19B8FF), background = Color.Black, surface = Color.Black)) {
                Surface(Modifier.fillMaxSize().statusBarsPadding()) {
                    if (unlocked) ChatScreen(store, speaker) else LockScreen { authenticate() }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        VrindaService.instance?.pause()
        if (stoppedAt > 0 && SystemClock.elapsedRealtime() - stoppedAt > LOCK_AFTER_MS) unlocked = false
    }

    override fun onStop() {
        super.onStop()
        stoppedAt = SystemClock.elapsedRealtime()
        VrindaService.instance?.resume()
    }

    override fun onDestroy() {
        speaker.shutdown()
        super.onDestroy()
    }

    private fun authenticate() {
        val auth = BiometricManager.Authenticators.BIOMETRIC_STRONG or
            BiometricManager.Authenticators.DEVICE_CREDENTIAL
        if (BiometricManager.from(this).canAuthenticate(auth) != BiometricManager.BIOMETRIC_SUCCESS) {
            unlocked = true // phone has no screen lock set
            return
        }
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    unlocked = true
                }
            })
        prompt.authenticate(
            BiometricPrompt.PromptInfo.Builder()
                .setTitle("VRINDA")
                .setSubtitle("Verify it's you")
                .setAllowedAuthenticators(auth)
                .build()
        )
    }
}

@Composable
fun LockScreen(onUnlock: () -> Unit) {
    LaunchedEffect(Unit) { onUnlock() }
    Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
        OrbView("idle", Modifier.size(280.dp))
        Text("VRINDA", style = MaterialTheme.typography.displaySmall, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(8.dp))
        Text("Locked")
        Spacer(Modifier.height(24.dp))
        Button(onClick = onUnlock) { Text("Unlock") }
    }
}

@Composable
fun ChatScreen(store: SecureStore, speaker: Speaker) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val brain = remember { Brain() }
    val msgs = remember { mutableStateListOf<Msg>() }
    val listState = rememberLazyListState()
    var input by remember { mutableStateOf("") }
    var langIdx by remember { mutableIntStateOf(store.langIdx.coerceIn(0, LANGS.size - 1)) }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var bgOn by remember { mutableStateOf(VrindaService.running) }
    var pending by remember { mutableStateOf<Pending?>(null) }
    var permWait by remember { mutableStateOf<CompletableDeferred<Boolean>?>(null) }
    var speaking by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { while (true) { speaking = speaker.isSpeaking(); delay(250) } }
    val orbState = when {
        busy -> "thinking"
        status == "Listening…" -> "listening"
        speaking -> "speaking"
        else -> "idle"
    }
    val orbH by animateDpAsState(if (msgs.isEmpty()) 270.dp else 150.dp, label = "orb")

    val actionPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        permWait?.complete(ok)
    }
    val actions = remember {
        Actions(
            ctx,
            confirm = { t -> Confirmer.ask(ctx, t, strong = false) },
            permission = { perm ->
                if (granted(ctx, perm)) true
                else {
                    val d = CompletableDeferred<Boolean>()
                    permWait = d
                    actionPerm.launch(perm)
                    d.await()
                }
            }
        )
    }

    // ---- background mode (wake word "Hey Vrinda") ----
    val bgMic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) { VrindaService.start(ctx); bgOn = true } else status = "Microphone permission needed"
    }
    fun startBg() {
        if (granted(ctx, Manifest.permission.RECORD_AUDIO)) { VrindaService.start(ctx); bgOn = true }
        else bgMic.launch(Manifest.permission.RECORD_AUDIO)
    }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { _ -> startBg() }
    fun setBackground(on: Boolean) {
        if (on) {
            if (Build.VERSION.SDK_INT >= 33 && !granted(ctx, Manifest.permission.POST_NOTIFICATIONS))
                notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
            else startBg()
        } else { VrindaService.stop(ctx); bgOn = false }
    }

    val recognizer = remember { SpeechRecognizer.createSpeechRecognizer(ctx) }
    DisposableEffect(Unit) { onDispose { recognizer.destroy() } }
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.size - 1) }

    fun send(text: String) {
        if (text.isBlank() || busy) return
        msgs.add(Msg(text, true)); input = ""; busy = true
        scope.launch {
            val reply = runCatching {
                brain.chat(store.apiKey, store.model, text, onSay = { msgs.add(Msg(it, false)); speaker.speak(it, detectLocale(it)) }) { n, a -> actions.run(n, a) }
            }.getOrElse { "Sorry, something went wrong: ${it.message}" }
            msgs.add(Msg(reply, false)); busy = false
            speaker.speak(reply, detectLocale(reply))
        }
    }

    fun startListening() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, LANGS[langIdx].tag)
        }
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { status = "Listening…" }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() { status = "" }
            override fun onError(e: Int) { status = "Didn't catch that" }
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
            override fun onResults(b: Bundle?) {
                status = ""
                b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { send(it) }
            }
        })
        recognizer.startListening(i)
    }

    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startListening() else status = "Microphone permission needed"
    }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text("VRINDA", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
            TextButton(onClick = { showSettings = true }) { Text("Settings") }
        }
        OrbView(orbState, Modifier.fillMaxWidth().height(orbH))
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(msgs) { m ->
                Row(Modifier.fillMaxWidth(), if (m.user) Arrangement.End else Arrangement.Start) {
                    Box(
                        Modifier.widthIn(max = 300.dp)
                            .background(if (m.user) Color(0xFF0B3C5D) else Color(0xFF2A2A2A), RoundedCornerShape(14.dp))
                            .padding(10.dp)
                    ) { Text(m.text) }
                }
            }
        }
        if (busy) Text("Thinking…", color = Color.Gray)
        if (status.isNotEmpty()) Text(status, color = Color.Gray)
        Row(Modifier.padding(vertical = 6.dp), Arrangement.spacedBy(8.dp)) {
            LANGS.forEachIndexed { idx, l ->
                FilterChip(selected = langIdx == idx, onClick = { langIdx = idx; store.langIdx = idx }, label = { Text(l.label) })
            }
        }
        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Type or speak…") })
            Button(onClick = { micPerm.launch(Manifest.permission.RECORD_AUDIO) }) { Text("🎤") }
            Button(onClick = { send(input) }) { Text("Send") }
        }
    }

    if (showSettings) SettingsDialog(
        store, LANGS[langIdx].label, bgOn,
        onBg = { setBackground(it) },
        onSetup = { setupBackground(ctx) },
        a11yOn = VrindaAccessibility.enabled,
        onA11y = { openAccessibility(ctx) },
        onVoice = { speaker.nextVoice(LANGS[langIdx].locale) },
        onClose = { showSettings = false }
    )

    pending?.let { p ->
        AlertDialog(
            onDismissRequest = { p.result.complete(false); pending = null },
            title = { Text("Confirm") },
            text = { Text(p.text) },
            confirmButton = { TextButton(onClick = { p.result.complete(true); pending = null }) { Text("Yes") } },
            dismissButton = { TextButton(onClick = { p.result.complete(false); pending = null }) { Text("No") } }
        )
    }
}

@Composable
fun SettingsDialog(
    store: SecureStore, langLabel: String, bgOn: Boolean,
    onBg: (Boolean) -> Unit, onSetup: () -> Unit, a11yOn: Boolean, onA11y: () -> Unit,
    onVoice: () -> Unit, onClose: () -> Unit
) {
    var key by remember { mutableStateOf(store.apiKey) }
    var model by remember { mutableStateOf(store.model) }
    var strict by remember { mutableStateOf(store.strictConfirm) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Settings") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(key, { key = it }, label = { Text("Gemini API key") },
                    visualTransformation = PasswordVisualTransformation(), singleLine = true)
                OutlinedTextField(model, { model = it }, label = { Text("Model name") }, singleLine = true)
                OutlinedButton(onClick = onVoice) { Text("Change voice ($langLabel) – tap to try next") }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("“Hey Vrinda” in background", Modifier.weight(1f))
                    Switch(checked = bgOn, onCheckedChange = onBg)
                }
                OutlinedButton(onClick = onSetup) { Text("Grant background permissions") }
                OutlinedButton(onClick = onA11y) { Text(if (a11yOn) "Screen control: ON ✔" else "Enable screen control") }
                val notifCtx = LocalContext.current
                OutlinedButton(onClick = {
                    notifCtx.startActivity(
                        Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }) { Text(if (VrindaNotifications.instance != null) "Notification access: ON ✔" else "Enable notification access") }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Fingerprint for sensitive actions in background", Modifier.weight(1f))
                    Switch(checked = strict, onCheckedChange = { strict = it; store.strictConfirm = it })
                }
            }
        },
        confirmButton = { TextButton(onClick = { store.apiKey = key; store.model = model; onClose() }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}

/** Vrinda's body: the SVG orb in assets/orb.html, floating in 3D. Offline: network loads are blocked. */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun OrbView(state: String, modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { c ->
            WebView(c).apply {
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                settings.javaScriptEnabled = true
                settings.allowFileAccess = false
                settings.allowContentAccess = false
                settings.blockNetworkLoads = true
                settings.domStorageEnabled = false
                isVerticalScrollBarEnabled = false
                isHorizontalScrollBarEnabled = false
                webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, url: String?) {
                        view.evaluateJavascript("setState('$state')", null)
                    }
                }
                val html = c.assets.open("orb.html").bufferedReader().use { it.readText() }
                loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
            }
        },
        update = { it.evaluateJavascript("if(window.setState)setState('$state')", null) },
        onRelease = { it.destroy() }
    )
}
