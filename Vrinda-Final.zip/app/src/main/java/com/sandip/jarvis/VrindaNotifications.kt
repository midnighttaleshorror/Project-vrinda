package com.sandip.jarvis

import android.app.Notification
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Lets Vrinda read the owner's current notifications and quick-reply to them. Nothing is stored. */
class VrindaNotifications : NotificationListenerService() {
    companion object {
        @Volatile var instance: VrindaNotifications? = null
        private val NUMBERS = Regex("\\b\\d{4,8}\\b")
        private val CODE_WORDS = Regex("otp|code|verification|password|passcode|pin|কোড|ওটিপি|कोड|ओटीपी", RegexOption.IGNORE_CASE)
        /** OTPs and codes are never read out. */
        fun safe(t: String) = if (CODE_WORDS.containsMatchIn(t)) NUMBERS.replace(t, "[hidden]") else t
    }

    override fun onListenerConnected() { instance = this }
    override fun onListenerDisconnected() { instance = null }
    override fun onDestroy() { instance = null; super.onDestroy() }

    private fun visible(): List<StatusBarNotification> =
        (activeNotifications ?: emptyArray()).filter {
            !it.isOngoing && it.packageName != packageName && !VrindaAccessibility.blocked(it.packageName)
        }.sortedByDescending { it.postTime }

    private fun appName(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    private fun title(n: StatusBarNotification) =
        n.notification.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""

    private fun body(n: StatusBarNotification): String {
        val e = n.notification.extras
        return (e.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: e.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
    }

    fun summary(max: Int): String {
        val list = try { visible() } catch (e: Exception) { return "I cannot read notifications right now." }
        if (list.isEmpty()) return "There are no notifications."
        return list.take(max.coerceIn(1, 15)).joinToString("\n") {
            "${appName(it.packageName)}: ${title(it)} — ${safe(body(it)).take(160)}"
        }
    }

    private fun find(who: String): StatusBarNotification? = try {
        visible().firstOrNull { n ->
            (title(n).contains(who, true) || appName(n.packageName).contains(who, true)) &&
                n.notification.actions?.any { it.remoteInputs?.isNotEmpty() == true } == true
        }
    } catch (e: Exception) { null }

    fun replyTarget(who: String): String? = find(who)?.let { "${title(it)} in ${appName(it.packageName)}" }

    fun reply(who: String, message: String): String {
        val hit = find(who) ?: return "I found no notification from “$who” that can be replied to."
        val action = hit.notification.actions.first { it.remoteInputs?.isNotEmpty() == true }
        val inputs = action.remoteInputs
        val results = Bundle()
        inputs.forEach { results.putCharSequence(it.resultKey, message) }
        val intent = Intent()
        RemoteInput.addResultsToIntent(inputs, intent, results)
        return try {
            action.actionIntent.send(this, 0, intent)
            "Replied to ${title(hit)} in ${appName(hit.packageName)}."
        } catch (e: Exception) { "The reply could not be sent." }
    }
}
