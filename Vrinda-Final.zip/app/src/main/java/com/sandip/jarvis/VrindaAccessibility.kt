package com.sandip.jarvis

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Lets Vrinda read the screen and tap / type / scroll. Banking, payment and password apps are off limits. */
class VrindaAccessibility : AccessibilityService() {
    companion object {
        @Volatile var instance: VrindaAccessibility? = null
        val enabled: Boolean get() = instance != null
        private const val PROTECTED = "This app is protected (banking, payment or passwords), so I will not read or operate it."
        private val BLOCKED = listOf(
            "bank", "paytm", "phonepe", "nbu.paisa", "bhim", "upi", "wallet", "authenticator",
            "bitwarden", "lastpass", "1password", "keepass", "dashlane", "passwords"
        )
        fun blocked(pkg: String) = BLOCKED.any { pkg.contains(it, ignoreCase = true) }
    }

    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }

    private fun root(): AccessibilityNodeInfo? = rootInActiveWindow

    fun snapshot(max: Int): String {
        val r = root() ?: return "Screen not readable."
        val pkg = r.packageName?.toString() ?: ""
        if (blocked(pkg)) return PROTECTED
        val seen = LinkedHashSet<String>()
        var len = 0
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 40 || len > max) return
            if (n.isVisibleToUser && !n.isPassword) {
                val t = (n.text ?: n.contentDescription)?.toString()?.trim()
                if (!t.isNullOrEmpty() && seen.add(t.take(80))) len += t.take(80).length + 3
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(r, 0)
        return "[App: $pkg] " + seen.joinToString(" | ").take(max)
    }

    fun clickText(q: String): String {
        val r = root() ?: return "Screen not readable."
        if (blocked(r.packageName?.toString() ?: "")) return PROTECTED
        val nodes = r.findAccessibilityNodeInfosByText(q)
        if (nodes.isNullOrEmpty()) return "Could not find '$q' on screen."
        val node = nodes.firstOrNull { it.isVisibleToUser } ?: nodes[0]
        return if (clickNode(node)) "Tapped '$q'." else "Found '$q' but could not tap it."
    }

    private fun clickNode(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        var i = 0
        while (n != null && i < 6) {
            if (n.isClickable && n.isEnabled) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            n = n.parent; i++
        }
        val b = Rect(); node.getBoundsInScreen(b)
        return tap(b.centerX(), b.centerY())
    }

    private fun tap(x: Int, y: Int): Boolean {
        val p = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        return dispatchGesture(
            GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build(), null, null
        )
    }

    private fun findEditable(n: AccessibilityNodeInfo?, depth: Int = 0): AccessibilityNodeInfo? {
        if (n == null || depth > 40) return null
        if (n.isEditable && n.isVisibleToUser) return n
        for (i in 0 until n.childCount) findEditable(n.getChild(i), depth + 1)?.let { return it }
        return null
    }

    private fun findScrollable(n: AccessibilityNodeInfo?, depth: Int = 0): AccessibilityNodeInfo? {
        if (n == null || depth > 40) return null
        if (n.isScrollable && n.isVisibleToUser) return n
        for (i in 0 until n.childCount) findScrollable(n.getChild(i), depth + 1)?.let { return it }
        return null
    }

    fun typeText(t: String): String {
        val r = root() ?: return "Screen not readable."
        if (blocked(r.packageName?.toString() ?: "")) return PROTECTED
        val node = r.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable }
            ?: findEditable(r) ?: return "No text field found. Tap a text field first."
        if (node.isPassword) return "That is a password field, so I will not type there."
        val cur = if (node.isShowingHintText) "" else node.text?.toString() ?: ""
        val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, cur + t) }
        return if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) "Typed the text." else "Could not type there."
    }

    fun scroll(dir: String): String {
        val r = root() ?: return "Screen not readable."
        if (blocked(r.packageName?.toString() ?: "")) return PROTECTED
        val up = dir.equals("up", true)
        val node = findScrollable(r)
        val action = if (up) AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD else AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        if (node != null && node.performAction(action)) return "Scrolled $dir."
        val m = resources.displayMetrics
        val x = m.widthPixels / 2f
        val (y1, y2) = if (up) m.heightPixels * .3f to m.heightPixels * .7f else m.heightPixels * .7f to m.heightPixels * .3f
        val p = Path().apply { moveTo(x, y1); lineTo(x, y2) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 300)).build(), null, null)
        return "Swiped $dir."
    }

    fun press(key: String): String {
        val code = when (key.lowercase()) {
            "back" -> GLOBAL_ACTION_BACK
            "home" -> GLOBAL_ACTION_HOME
            "recents" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            "quick_settings" -> GLOBAL_ACTION_QUICK_SETTINGS
            "lock_screen" -> GLOBAL_ACTION_LOCK_SCREEN
            "screenshot" -> GLOBAL_ACTION_TAKE_SCREENSHOT
            "power" -> GLOBAL_ACTION_POWER_DIALOG
            else -> return "Unknown key '$key'."
        }
        return if (performGlobalAction(code)) "Pressed $key." else "Could not press $key."
    }

    private fun editableNode(): AccessibilityNodeInfo? {
        val r = root() ?: return null
        return r.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable } ?: findEditable(r)
    }

    /** Why the text field cannot be edited, or null when it can. */
    fun fieldProblem(): String? {
        val r = root() ?: return "Screen not readable."
        if (blocked(r.packageName?.toString() ?: "")) return PROTECTED
        val n = editableNode() ?: return "No text field found. Tap a text field first."
        if (n.isPassword) return "That is a password field, so I will not edit it."
        return null
    }

    /** Text typed in the field and the cursor position, or null when the field is empty. */
    fun fieldSnapshot(): Pair<String, Int>? {
        val n = editableNode() ?: return null
        if (n.isShowingHintText) return null
        val t = n.text?.toString() ?: return null
        if (t.isEmpty()) return null
        val c = n.textSelectionEnd
        return t to (if (c < 0 || c > t.length) t.length else c)
    }

    /** Replaces the field's text and puts the cursor at [cursor]. */
    fun setField(text: String, cursor: Int): Boolean {
        val n = editableNode() ?: return false
        val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        if (!n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) return false
        val sel = Bundle().apply {
            putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, cursor)
            putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, cursor)
        }
        n.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel)
        return true
    }
}
