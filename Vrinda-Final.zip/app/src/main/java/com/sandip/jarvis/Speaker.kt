package com.sandip.jarvis

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class Speaker(ctx: Context, private val store: SecureStore) {
    @Volatile private var ready = false
    private lateinit var tts: TextToSpeech
    private val waiting = ConcurrentHashMap<String, CompletableDeferred<Unit>>()

    init {
        tts = TextToSpeech(ctx) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) { id?.let { waiting.remove(it)?.complete(Unit) } }
                @Deprecated("Deprecated in Java")
                override fun onError(id: String?) { id?.let { waiting.remove(it)?.complete(Unit) } }
                override fun onError(id: String?, errorCode: Int) { id?.let { waiting.remove(it)?.complete(Unit) } }
            })
        }
    }

    private fun voicesFor(l: Locale): List<Voice> =
        (tts.voices ?: emptySet<Voice>())
            .filter { it.locale.language == l.language }
            .filter { it.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) != true }
            .sortedBy { it.name }

    private fun say(text: String, l: Locale, id: String) {
        val list = voicesFor(l)
        val saved = store.voiceFor(l.language)
        val v = list.firstOrNull { it.name == saved }
            ?: list.firstOrNull { it.locale.country == l.country }
            ?: list.firstOrNull()
        if (v != null) tts.voice = v else tts.language = l
        tts.setPitch(1.15f)
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
    }

    fun speak(text: String, l: Locale) {
        if (ready) say(text, l, "vrinda")
    }

    /** Speaks and waits until finished, so the mic never hears Vrinda herself. */
    suspend fun speakSuspend(text: String, l: Locale) {
        if (!ready) return
        val id = UUID.randomUUID().toString()
        val d = CompletableDeferred<Unit>()
        waiting[id] = d
        say(text, l, id)
        withTimeoutOrNull(30_000) { d.await() }
        waiting.remove(id)
        delay(250)
    }

    fun nextVoice(l: Locale) {
        val list = voicesFor(l)
        if (list.isEmpty()) return
        val cur = list.indexOfFirst { it.name == store.voiceFor(l.language) }
        val next = list[(cur + 1) % list.size]
        store.setVoice(l.language, next.name)
        speak(
            when (l.language) {
                "hi" -> "नमस्ते, मैं वृंदा हूँ।"
                "bn" -> "নমস্কার, আমি বৃন্দা।"
                else -> "Hello, I am Vrinda."
            }, l
        )
    }

    fun isSpeaking(): Boolean = ready && tts.isSpeaking

    fun stop() { if (ready) tts.stop() }
    fun shutdown() { tts.shutdown() }
}
